# 📦 Awesome Apps · 软件精选

> 分享值得使用的软件，覆盖 **macOS、Windows、iOS、Android**。按平台浏览、按用途查找，持续更新。

![Platforms](https://img.shields.io/badge/Platforms-4-1677ff) ![Apps](https://img.shields.io/badge/Apps-21-555555) ![License](https://img.shields.io/badge/List-Community%20Sharing-4c956c)

推荐星级仅代表个人体验，收费政策以软件官网为准。

## 🧭 平台导航

[🍎 macOS](#-macos) · [🪟 Windows](#-windows) · [📱 iOS](#-ios) · [🤖 Android](#-android)

> **收费模式**：免费｜免费增值（基础免费、高级功能收费）｜买断｜订阅｜自愿付费。  
> **说明**：同一款软件可能出现在多个平台；顶部 **21 款**为去重后的软件数量。未确认移动端支持的软件不强行归类。

---

## 🍎 macOS

### ⚡ 效率

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [PixPin](https://pixpin.cn/) | 截图、贴图、长截图、OCR 与 GIF 录制 | 免费增值 | ⭐⭐⭐⭐ |
| [QSpace](https://qspace.awehunt.com) | 多窗格文件管理器 | 买断 | ⭐⭐⭐⭐ |
| [Bob](https://bobtranslate.com/) | 翻译与 OCR 文字识别 | 买断 | ⭐⭐⭐⭐ |
| [Bitwarden](https://bitwarden.com/) | 开源跨平台密码管理器 | 免费增值 | ⭐⭐⭐⭐ |
| [1Password](https://1password.com) | 密码及通行密钥管理器 | 订阅 | ⭐⭐⭐⭐ |
| [Snipaste](https://zh.snipaste.com) | 截图、标注和贴图 | 免费增值 | ⭐⭐⭐ |
| [Raycast](https://www.raycast.com/) | 启动器、搜索、剪贴板与自动化 | 免费增值 | ⭐⭐⭐⭐ |

> 💡 **QSpace 优惠**：购买 QSpace Pro 时使用邀请码 `SA4BHH`，可优惠 10 元（以商家实际活动为准）。

### ⚙️ 系统

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Thaw](https://github.com/stonerl/Thaw) | 菜单栏图标管理 | 免费 | ⭐⭐⭐⭐⭐ |
| [LayoutKeeper](https://github.com/tumingke0/LayoutKeeper) | 外接显示器窗口布局恢复与亮度联动 | 免费 | ⭐⭐⭐⭐ |

### 🎨 美化

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [pap.er.](https://paper.photos) | 桌面壁纸工具 | 免费 | ⭐⭐⭐⭐ |

### ✏️ 设计

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Blender](https://www.blender.org) | 3D 建模、动画与渲染 | 免费 | ⭐⭐⭐⭐ |
| [Eagle](https://eagle.cool) | 图片、视频和设计素材管理 | 买断 | ⭐⭐⭐⭐ |
| [Sketch](https://www.sketch.com) | UI/UX 与矢量界面设计 | 订阅 | ⭐⭐⭐⭐ |
| [Figma](https://www.figma.com) | 云端协作设计工具 | 免费增值 | ⭐⭐⭐⭐ |
| [PureRef](https://www.pureref.com) | 参考图片整理与展示 | 自愿付费 | ⭐⭐⭐ |

### 🎬 影音

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [IINA](https://iina.io/) | 基于 mpv 的视频播放器 | 免费 | ⭐⭐⭐⭐⭐ |
| [QuickRecorder](https://lihaoyun6.github.io/quickrecorder/) | 轻量开源屏幕录制 | 免费 | ⭐⭐⭐⭐⭐ |

### 📦 解压

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Keka](https://www.keka.io/en/) | 多格式压缩与解压；官网版可免费获取 | 免费 | ⭐⭐⭐⭐ |
| [Bandizip](https://www.bandisoft.com/bandizip.mac/) | 压缩与解压工具 | 买断 | ⭐⭐⭐⭐ |

### 🤖 AI

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Magpie](https://usemagpie.ai/zh/) | AI 编程工具模型与 API 配置管理 | 免费 | ⭐⭐⭐⭐ |
| [CC-Switch](https://ccswitch.io/zh/) | AI 编程服务商与模型配置切换 | 免费 | ⭐⭐⭐⭐ |

---

## 🪟 Windows

### ⚡ 效率与安全

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [PixPin](https://pixpin.cn/) | 截图、贴图、长截图、OCR 与 GIF 录制 | 免费增值 | ⭐⭐⭐⭐ |
| [Snipaste](https://zh.snipaste.com) | 截图、标注和贴图 | 免费增值 | ⭐⭐⭐ |
| [Bitwarden](https://bitwarden.com/) | 开源跨平台密码管理器 | 免费增值 | ⭐⭐⭐⭐ |
| [1Password](https://1password.com) | 密码及通行密钥管理器 | 订阅 | ⭐⭐⭐⭐ |

### ✏️ 设计

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Blender](https://www.blender.org) | 3D 建模、动画与渲染 | 免费 | ⭐⭐⭐⭐ |
| [Eagle](https://eagle.cool) | 图片、视频和设计素材管理 | 买断 | ⭐⭐⭐⭐ |
| [Figma](https://www.figma.com) | 云端协作设计工具 | 免费增值 | ⭐⭐⭐⭐ |
| [PureRef](https://www.pureref.com) | 参考图片整理与展示 | 自愿付费 | ⭐⭐⭐ |

### 📦 解压

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Bandizip](https://www.bandisoft.com/bandizip/) | 多格式压缩与解压工具 | 免费增值 | ⭐⭐⭐⭐ |

### 🤖 AI

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Magpie](https://usemagpie.ai/zh/) | AI 编程工具模型与 API 配置管理 | 免费 | ⭐⭐⭐⭐ |
| [CC-Switch](https://ccswitch.io/zh/) | AI 编程服务商与模型配置切换 | 免费 | ⭐⭐⭐⭐ |

---

## 📱 iOS

### 🔐 密码管理

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Bitwarden](https://bitwarden.com/) | 密码、通行密钥及跨设备同步 | 免费增值 | ⭐⭐⭐⭐ |
| [1Password](https://1password.com) | 密码及通行密钥管理 | 订阅 | ⭐⭐⭐⭐ |

> 📌 其他 iOS 应用持续补充中，欢迎通过 Issue 推荐。

---

## 🤖 Android

### 🔐 密码管理

| 软件 | 简介 | 收费模式 | 推荐度 |
| :--- | :--- | :--- | :--- |
| [Bitwarden](https://bitwarden.com/) | 密码、通行密钥及跨设备同步 | 免费增值 | ⭐⭐⭐⭐ |
| [1Password](https://1password.com) | 密码及通行密钥管理 | 订阅 | ⭐⭐⭐⭐ |

> 📌 其他 Android 应用持续补充中，欢迎通过 Issue 推荐。

---

## 💬 参与分享

欢迎通过 [Issues](../../issues) 推荐软件、反馈失效链接或纠正收费信息。如果这份清单对你有帮助，欢迎点亮 ⭐ Star。
